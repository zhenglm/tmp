#!/usr/bin/env bash

while true
do

ABS_PATH="/home/dm/zhengliming/voice/"
for line in `cat /home/dm/zhengliming/voice/download_path`
do
FILE_PATH=$line
if [ -z ${FILE_PATH} ]; then
    break;
fi
if [ ! -f ${ABS_PATH}/pcm_gender_output_passenger/${FILE_PATH}/_SUCCESS ]; then
    continue;
fi

DATE=${FILE_PATH////}

YEAR=`date -d ${DATE} +%Y`
MONTH=`date -d ${DATE} +%m`
DAY=`date -d ${DATE} +%d`


sh -x ${ABS_PATH}/pcm_gender_output_passenger/run_merge_gender_result_someday.sh ${DATE}

sh -x ${ABS_PATH}/gender_result_to_hive/run_gender_result_to_hive.sh ${DATE}

#get uncorrect mp3
#sh -x ./pcm_gender_output_passenger/run_get_uncorrect_phone.sh ${DATE}

#cat ./pcm_gender_output_passenger/uncorrect.rst | xargs echo "cp ./${YEAR}/${MONTH}/${DAY}/"

rm ${ABS_PATH}/pcm_gender_output_passenger/${FILE_PATH}/_SUCCESS
done # for

sleep 300
done # while
