#!/usr/bin/env bash

DATE=$1
if [ -z ${DATE} ]; then
    DATE=`date -d '-1 day' +%Y%m%d`
fi

YEAR=`date -d ${DATE} +%Y`
MONTH=`date -d ${DATE} +%m`
DAY=`date -d ${DATE} +%d`

FILE_NAME=./${YEAR}/${MONTH}/${DAY}

PCM_OUTPUT_PATH_PASSENGER="pcm_gender_output_passenger"

mkdir ${PCM_OUTPUT_PATH_PASSENGER}
gender_recog_result="gender_recog_result_${DATE}"

#.mp3 to .pcm :ffmpeg
dir_list=`ls -d ${FILE_NAME}/xyz*_dir`
for dir in ${dir_list}
do
    sh -x run_passenger_voice_gender.sh ${dir} ${PCM_OUTPUT_PATH_PASSENGER} ${gender_recog_result} ${DATE} & 
done #dir for
#wait
#rm  -fr ${FILE_NAME}

