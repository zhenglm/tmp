#!/usr/bin/env bash

echo '>>>>>>>>>>>>>>>>>>>> start_time: ' `date`
source /etc/profile
BEGIN_TIME=`date +%s`


DATE=$1

if [ -z ${DATE} ]; then
    DATE=`date -d '-1 day' +%Y%m%d`
fi

YEAR=`date -d ${DATE} +%Y`
MONTH=`date -d ${DATE} +%m`
DAY=`date -d ${DATE} +%d`


OUTPUT_PATH="/user/rd/dm/voice/fast/${YEAR}/${MONTH}/${DAY}"
RECORD_SQL_FILE_NAME="/home/dm/zhengliming/voice/script/sql/record.sql"

hive -e "
alter table dm.voice_fast add if not exists partition (year = '${YEAR}', month = '${MONTH}', day ='${DAY}') location \"${OUTPUT_PATH}\";
"

spark-submit    --driver-memory 4g \
                --conf "spark.dynamicAllocation.minExecutors=50" \
                --conf "spark.dynamicAllocation.maxExecutors=200" \
                --conf spark.sql.shuffle.partitions=1000 \
                --conf spark.akka.frameSize=1000 \
                --conf spark.storage.memoryFraction=0.2 \
                --conf spark.default.parallelism=9600 \
                --num-executors 300 \
                --class data_fetch.DataFetchTool \
                /home/dm/zhengliming/voice/intelli-dm-1.0.jar \
                --output_path "${OUTPUT_PATH}" \
                --sql_file_name "${RECORD_SQL_FILE_NAME}" \
                --data_date "${YEAR}-${MONTH}-${DAY}" \


END_TIME=`date +%s`
echo '>>>>>>>>>>>>>>>>>>>> end_time: ' `date`
echo '++++++++++++++++++++ Total Cost: ' $((END_TIME-BEGIN_TIME)) 'seconds!'
