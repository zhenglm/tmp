#!/usr/bin/env bash

#待分析路径
DIR=$1
#目标结果路径
DEST_FILE=$2
#结果存储文件
gender_recog_result=$3
DATE=$4

rm -r ${DEST_FILE}/${DIR}/gender_recog_result_*
mkdir -p ${DEST_FILE}/${DIR}

split_file_list=`ls -d ${DIR}/split*_dir`
for split_file in ${split_file_list}
do
    file_list=`ls ${split_file} | grep mp3`
    for file in ${file_list}
    do
    echo ${file}
    dest_file_name=`echo ${file}| sed 's/\.mp3//'`
    echo "#############" ${dest_file_name}
    sound_channel=${dest_file_name:0:1}
    if [ ${sound_channel} == "0" ]; then
        channel="0.0.0"
    else
        channel="0.0.1"
    fi
    echo "channel " ${channel}
    ./gender_recog_tool/ffmpeg -i ${split_file}/${file} -f s16le -ar 8000 -ac 1 -acodec pcm_s16le -map_channel ${channel} ${DEST_FILE}/${DIR}/${dest_file_name}.pcm
              
    #.pcm to gender :gender_recog Output: 1-male, 2-female, 0-others
    #and save gender_recog result
    phone=${dest_file_name:0-11}
<<del
hive -e "
insert into dm.passenger_gender_voice(phone, gender, voice_time) values(${phone}, `./gender_recog_tool/gender_recog ${DEST_FILE}/${DIR}/${dest_file_name}.pcm`, ${DATE});
"
del
    echo ${dest_file_name} " " `./gender_recog_tool/gender_recog ${DEST_FILE}/${DIR}/${dest_file_name}.pcm` " " ${DATE} >> ${DEST_FILE}/${DIR}/${gender_recog_result}
    rm ${DEST_FILE}/${DIR}/${dest_file_name}.pcm
    done
done
