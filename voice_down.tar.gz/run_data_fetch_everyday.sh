#! /usr/bin/env bash

BEGIN_DATE=$1
if [ -z ${BEGIN_DATE} ]; then
    BEGIN_DATE=`date -d '1 day ago' +%Y%m%d`
fi

END_DATE=`date -d "1 month ago ${BEGIN_DATE}" +%Y%m%d`
echo ${END_DATE}
while [[ "${BEGIN_DATE}" > "${END_DATE}" ]]
do
    echo '\n******************** ' "${BEGIN_DATE}" 'begin！\n'
    ./run_data_fetch.sh ${BEGIN_DATE}
    echo '******************** ' "${BEGIN_DATE}" 'finish!\n'
    
    BEGIN_DATE=`date -d "1 day ago ${BEGIN_DATE}" +%Y%m%d`
done

echo '>>>>>>>>>>>>>>>>>>>> end!'
echo '\n'




