#!/usr/bin/env bash

FILE_PATH=$1

file_list=`ls ${FILE_PATH}/split*`
for file in $file_list
do
    if [ -f ${FILE_PATH}/../${file}_dir/_SUCCESS ]; then
        continue;
    fi
    
    rm -r ${file}_dir
    mkdir ${file}_dir
    cat $file|while read pid_phone url src;do wget ${url} -O "${file}_dir/${src}${pid_phone}.mp3"; done
    touch ${file}_dir/_SUCCESS
done





