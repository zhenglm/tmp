#!/usr/bin/env bash

echo '\n>>>>>>>>>>>>>>>>>>>> start time : ' `date`
source /etc/profile
BEGIN_TIME=`date +%s`
DATE=$1
if [ -z ${DATE} ]; then
    DATE=`date -d '-2 day' +%Y%m%d`
fi

YEAR=`date -d ${DATE} +%Y`
MONTH=`date -d ${DATE} +%m`
DAY=`date -d ${DATE} +%d`

ABS_PATH="/home/dm/zhengliming/voice/"

DOWNLOAD_PATH="${ABS_PATH}/${YEAR}/${MONTH}/${DAY}"
echo /${YEAR}/${MONTH}/${DAY} >>/home/dm/zhengliming/voice/download_path
SOURCE_DATA_PATH="/user/rd/dm/voice/fast/${YEAR}/${MONTH}/${DAY}"
DEST_DATA_PATH="/user/rd/dm/ods/voice/fast/${YEAR}/${MONTH}/${DAY}"
#rm -fr ${DOWNLOAD_PATH}
mkdir -p ${DOWNLOAD_PATH}

if [ ! -f ${DOWNLOAD_PATH}/_SPLITSUCCESS ]; then 
    echo "select concat(pid,cus_tel) key,record_url,src_is_drv from dm.voice_fast where concat(year,month,day)='$DATE'"
    hive -e "select concat(pid,cus_tel) key,record_url,src_is_drv from dm.voice_fast where concat(year,month,day)='$DATE'" >${DOWNLOAD_PATH}/voice_info
    THREAD_NUM=10
    linenum=`wc -l ${DOWNLOAD_PATH}/voice_info|awk '{print $1}'`
    echo 'linenum: ' ${linenum}
    linenum_per_proc=`echo "${linenum}" / "${THREAD_NUM}"|bc`
    echo 'line per proc : ' ${linenum_per_proc}

    split -l $linenum_per_proc ${DOWNLOAD_PATH}/voice_info -d "${DOWNLOAD_PATH}/xyz"

    linenum_per_time=`echo "${linenum_per_proc}" / 10|bc`
    split_list=`ls ${DOWNLOAD_PATH}/xyz* | grep -v _dir`
    for every_split in ${split_list} 
    do 
        mkdir -p ${every_split}_dir
        split -l ${linenum_per_time} ${every_split} -d "${every_split}_dir/split"
    done #for
        touch ${DOWNLOAD_PATH}/_SPLITSUCCESS
fi

path_list=`ls -d ${DOWNLOAD_PATH}/xyz*_dir | grep -v split`
for path in ${path_list}
do
#echo ${path}
sh -x ${ABS_PATH}/run_download_mp3.sh ${path} &
done



wait
touch ${DOWNLOAD_PATH}/_SUCCESS

END_TIME=`date +%s`
echo '>>>>>>>>>>>>>>>>>>>> end time : ' `date`
echo '++++++++++++++++++++ Total Cost: ' $((END_TIME-BEGIN_TIME)) ' seconds!\n'
