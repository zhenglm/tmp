#!/usr/bin/env bash

while true
do
ABS_PATH="/home/dm/zhengliming/voice/"
for line in `cat download_path`
do
FILE_PATH=$line
if [ -z ${FILE_PATH} ]; then
    break   
fi
if [ ! -f ${ABS_PATH}/${FILE_PATH}/_SUCCESS ] ;then
    continue
fi

DATE=${FILE_PATH////} 
echo "FILE PATH" ${FILE_PATH}

#echo " +++++++++++++   " ${DATE#*.}
#gender_recog
sh -x ./run_produce_user_gender.sh ${DATE}  

DEST_DATA_PATH="/user/rd/dm/ods/voice/fast/${FILE_PATH#*/}"
hadoop fs -mkdir -p ${DEST_DATA_PATH}
echo ${DEST_DATA_PATH}

file_list=`ls -d ${ABS_PATH}/${FILE_PATH}/xyz*_dir`
for file in ${file_list}
do
    #echo ${file}
    tar -vcf ${file}.tar ${file} 
    #upload
    hadoop fs -put ${file}.tar "${DEST_DATA_PATH}/${file##*/}.tar" 
    rm  ${file}.tar
    #rm -r ${file}
done #for
wait
touch ${ABS_PATH}/pcm_gender_output_passenger/${FILE_PATH}/_SUCCESS
rm  -fr ${ABS_PATH}/${FILE_PATH}
done #for
sleep 100
done #while
