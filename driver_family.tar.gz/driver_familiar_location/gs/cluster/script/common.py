#!/usr/bin/env python
#-*- coding: utf-8 -*-

import sys

def conf_init(conf_file, conf_items):
    c_fp = open(conf_file)
    if c_fp == None:
        print >>sys.stderr, "open conf file fail"
        return 1
    for line in c_fp:
        line = line[:-1]
        parts = line.split("=")
        if len(parts) != 2:
            continue
        conf_items[parts[0].strip()] =  parts[1].strip()
    return 0

class Order:
    def __init__(self, id, phone,create_time,lat, lng):
        self.id = id
        self.lat = lat
        self.lng = lng
        self.phone = phone
        self.create_time = create_time
    def dump(self):
        return "%d|%d|%s|%f|%f" % (self.id, self.phone, self.create_time, self.lat, self.lng)


class Cluster:
    def __init__(self, lng, lat, density, radius, phone, flag, create_time, even_start):
        self.lng = lng
        self.lat = lat
        self.radius = radius
        self.density = density
        self.phone = phone
        self.flag = flag
        self.create_time =create_time
    def dump(self):
        return "%d\t%0.5f#%0.5f\t%d\t%0.3f" % (self.phone, self.lng, self.lat, self.density, self.radius )

