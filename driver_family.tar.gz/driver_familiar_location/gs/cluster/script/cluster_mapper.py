#!/usr/bin/env python

import os, sys
import common


for line in sys.stdin:
    parts = line.strip('\n').split("\t")
    if len(parts) != 5:
        #print >> sys.stderr, "input error, parts should be 5, phone, t_date, lng, lat, count"
        continue
    if parts[0] == '\\N':
        continue
    try:
        phone = parts[0]
        create_time = '1'
        lng = float(parts[2])
        lat = float(parts[3])
        print "%s\t%s\t%s\t%s" %(phone, create_time, lng, lat)
    except ValueError:
        pass






