#!/usr/bin/env python
#-*-coding:utf-8 -*-
import math

PI = 3.1415926
EARTH_RADIUS=6378.137
def sphere_distance(lat1,lng1,lat2,lng2):
    radlat1=rad(lat1)
    radlat2=rad(lat2)
    a=radlat1-radlat2
    b=rad(lng1)-rad(lng2)
    s=2*math.asin(math.sqrt(math.pow(math.sin(a/2),2)+math.cos(radlat1)*math.cos(radlat2)*math.pow(math.sin(b/2),2)))

    s=round(float(s*EARTH_RADIUS),3)
    if s<0:
        return -s
    else:
        return s

def rad(d):
    return d * PI / 180.0;

if __name__ == "__main__":
    print sphere_distance(40.08090, 116.37247,40.05180,116.31430)
    print sphere_distance(34.710, 113.651,34.725,113.654)


"""
115.989 40.443  178     0.277   1
115.989 40.457
"""
