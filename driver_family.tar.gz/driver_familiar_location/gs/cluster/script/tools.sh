function error()
{
    msg=$1
    echo "ERROR:"$msg >2
}
