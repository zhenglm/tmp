#!/usr/bin/env python

import sys
import math
from sphere_distance import *
from operator import itemgetter, attrgetter
import numpy as np
import common


def build_distance(order_list):
    #calculate order distance, input: order_list, order class, output: distance dictionary, max distance, min distance, max continues id
    distance = {}
    min_dis, max_dis = sys.float_info.max, 0.0
    max_id = 0
    non_diagonal_num = 0
    order_len = len(order_list)
    #iterate from begining
    for o_ind in xrange(order_len - 1):
        o_lat = order_list[o_ind].lat
        o_lng = order_list[o_ind].lng
        o_id = order_list[o_ind].id
        #compare instance later
        for i_ind in xrange(o_ind + 1, order_len):
            i_lat = order_list[i_ind].lat
            i_lng = order_list[i_ind].lng
            i_id = order_list[i_ind].id
            temp_distance = sphere_distance(o_lat, o_lng, i_lat, i_lng)
            min_dis, max_dis = min(min_dis, distance), max(max_dis, temp_distance)
            distance[(o_id,i_id)] = temp_distance
            distance[(i_id,o_id)] = temp_distance
            non_diagonal_num += 2
    max_id = len(order_list)
    distance[(0,0)] = 0
    diagonal_num = 0
    for i in xrange(1, max_id+1):
        distance[(i,i)] = 0
        diagonal_num += 1
    return distance, non_diagonal_num, max_dis, min_dis, max_id, diagonal_num

def select_dc(max_id,  distance):
    percent = 2
    position = int(max_id * (max_id + 1)/2 * percent /100)
    dc = sorted(distance.value())[position * 2 + max_id]
    return dc


def local_density(max_id, distance, dc, order_list, gauss=False, cutoff=True):
    assert gauss and cutoff == False and gauss or cutoff == True
    gauss_func = lambda dij,dc : math.exp(-(dij/dc)**2)
    cutoff_func = lambda dij,dc : 1 if dij < dc else 0
    func = gauss and gauss_func or cutoff_func
    rho = [-1] + [0] * max_id
    for i in xrange(1, max_id):
        for j in xrange(i + 1, max_id + 1):
            rho[i] += func(distance[(i,j)],dc)
            rho[j] += func(distance[(i,j)],dc)
    return rho

def min_distance(max_id, max_dis, distance, rho):
    rho = np.asarray(rho)
    sort_rho_idx = np.argsort(-rho)
    delta = [0.0] + [float(max_dis)] * (len(rho) - 1)
    n_neigh = [0] * len(rho)
    delta[sort_rho_idx[0]] = -1

    for i in xrange(1,max_id):
        for j in xrange(0,i):
            old_i, old_j = sort_rho_idx[i], sort_rho_idx[j]
            if distance[(old_i,old_j)] < delta[old_i]:
                delta[old_i] = distance[(old_i,old_j)]
                n_neigh[old_i] = old_j
    delta[sort_rho_idx[0]] = max(delta)
    return delta, n_neigh

class DensityPeakCluster(object):
    def local_density(self, load_func, order_list, gauss, dc=None):
        distance,non_diagonal_num,max_dis,min_dis,max_id,diagonal_num = load_func(order_list)
        if dc == None:
            dc = select_dc(max_id,distance)
        if dc <= 0:
            print >> sys.stderr, "dc is less than 0"
            return 1
        rho = local_density(max_id,distance,dc,order_list,gauss)
        return distance,max_dis,min_dis,max_id,rho,dc

    def cluster_data(self, load_func, order_list, density_threshold, distance_threshold, gauss, dc = None):
        non_diagonal_num = 0
        distance,max_dis,min_dis,max_id,rho,dc = self.local_density(load_func, order_list, gauss, dc=dc)
        delta,n_neigh = min_distance(max_id,max_dis,distance,rho)
        lng_v = []
        lat_v = []
        phone_v = []
        order_len = len(order_list)
        for i in xrange(order_len):
            temp_phone = order_list[i].phone
            temp_lat = order_list[i].lat
            temp_lng = order_list[i].lng
            phone_v.append(temp_phone)
            lat_v.append(temp_lat)
            lng_v.append(temp_lng)
        cluster, c_center = {}, {}  #cluster center and cluster number
        for idx, (i_density, m_distance, n_neigh_item,lng_vector,lat_vector,phone_vector) in enumerate(zip(rho, delta, n_neigh,lng_v,lat_v,phone_v)):
            if idx ==0:
                continue
            if i_density >= density_threshold and m_distance >= distance_threshold:
                c_center[idx] = idx
                cluster[idx] = idx
                #print "%s\t%0.4f\t%0.4f\t%d" %(phone_vector, lng_vector, lat_vector, i_density)
                #print "%s\t%0.3f\t%0.3f\t%d" %(order_list[idx - 1].phone, order_list[idx - 1].lng, order_list[idx - 1].lat, i_density)

        time_span={} #key:cluster center, value:time_list
        rr=[]
        sort_rho_idx=[] #number of node sort by rho and reverse
        for idx,r in enumerate(rho):
            rr.append([idx,r])
        bb=sorted(rr,key = lambda list1: list1[1],reverse=True) #sort by rho and reverse
        for i in range(len(bb)):
            sort_rho_idx.append(bb[i][0])
        for idx in sort_rho_idx :
            if idx in c_center:
                time_span.setdefault(idx,[])
                time_span[idx].append(order_list[idx-1].create_time)
                continue
            if n_neigh[idx] in cluster:
                cluster[idx] = cluster[n_neigh[idx]]
                time_span.setdefault(cluster[idx],[])
                time_span[cluster[idx]].append(order_list[idx-1].create_time)

        time_info=[]
        for center,time_list in time_span.items():
            time_max_cnt = {}
            time_center=0
            for i in range(len(time_list)):
                if time_list[i] == '0000-00-00 00:00:00':
                    continue
                try:
                    tm = time_list[i].split(' ')[1].split(':')[0]
                    time_max_cnt.setdefault(tm,0)
                    time_max_cnt[tm] += 1
                except :
                    pass   # wrong time format
            max_cnt = 0    # time's max cnt
            time_max = ''    # max cnt time
            for tm,cnt in time_max_cnt.items():
                if cnt > max_cnt :
                    max_cnt = cnt
                    time_max = tm

            time_info.append([center,rho[center],time_max])
        for j in range(len(time_info)):
            idx = time_info[j][0]
            time_max = time_info[j][2]
            print "%s\t%0.3f\t%0.3f\t%d_%s" %(order_list[idx - 1].phone, order_list[idx - 1].lng, order_list[idx - 1].lat, rho[idx], time_max) #len(rho) == len(order_list) + 1



        self.c_center = c_center
        self.distance = distance
        self.max_id = max_id
        return 0




if __name__ == "__main__":
    densityCluster = DensityPeakCluster()
    id = 0
    fs=open('test.data')
    test_data =[]
    for line in fs:
        id += 1
        parts = line.strip().split('\t')
        parts[2] = float(parts[2])
        parts[3] = float(parts[3])
        order_t = common.Order(id, parts[0],parts[1],parts[2],parts[3])
        test_data.append(order_t)
    densityCluster.cluster_data(build_distance, test_data, 4, 0.5, 0, 0.2)
