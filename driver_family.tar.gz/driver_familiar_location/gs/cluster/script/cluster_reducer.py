#!/usr/bin/env python


import os, sys
import common
import cluster
import random
CLUSTER_MAX_POINTNUM = 300


def cluster_reducer(fp):
    """
    select points to cluster
    """
    densityCluster = cluster.DensityPeakCluster()
    density_threshold = float(os.getenv("DENSITY_THRESHOLD"))
    distance_threshold_s = os.getenv("DISTANCE_THRESHOLD")
    dc_s = os.getenv("DC")
    #gauss = int(os.getenv("GAUSS"))
    '''
    density_threshold = 5
    distance_threshold_s = 1
    dc_s = 0.4
    gauss = 0
    '''
    if dc_s == "none":
        dc = None
    else:
        dc = float(dc_s)

    if distance_threshold_s == "none":
        distance_threshold = None
    else:
        distance_threshold = float(distance_threshold_s)

    gauss = 0

    #initialization
    id = 0
    order_list = []
    first_flag = True
    pre_m_lat = 0
    pre_m_lng = 0
    linenum = 0
    start_flag = False
    #random.seed()
    pre_phone = ''

    #read line by line
    for line in fp:
        linenum += 1
        line = line[:-1]
        parts = line.split("\t")

        #check data format
        if len(parts) != 4:
            continue
        #assignment
        phone = parts[0]
        create_time = parts[1]
        lng = float(parts[2])
        lat = float(parts[3])

        #if wrong data, skip
        if(lng==0.0 or lng=='\\N' or lat==0.0):
            continue
        #record every 1000
        #if linenum % 1000 == 0:
        #    print >>sys.stderr, "process the %d line" %linenum

        #new phone , then do the density peak for old phone
        if (phone != pre_phone) and not first_flag:
            if len(order_list) <= CLUSTER_MAX_POINTNUM:
                densityCluster.cluster_data(cluster.build_distance, order_list, density_threshold, distance_threshold,  gauss, dc)
            id = 0
            del order_list[:]

        id += 1
        pre_phone = phone
        try:
            int_phone = int(phone)
            order = common.Order(id, int_phone, create_time, lat, lng)
            order_list.append(order)
        except ValueError:
            pass
        first_flag = False
    #the last one
    if len(order_list) > 0:
        densityCluster.cluster_data(cluster.build_distance, order_list, density_threshold, distance_threshold, gauss, dc)
    return 0

if __name__ == "__main__":
    cluster_reducer(sys.stdin)







