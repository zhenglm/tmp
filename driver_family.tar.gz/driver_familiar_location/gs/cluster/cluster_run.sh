#!/bin/bash
source conf/common.conf
source script/tools.sh

#$HADOOP_HOME/bin/hadoop fs -rm -r ${output_dir}
function cluster()
{
    step=$1
    input_dir=$2
    output_dir=$3
    DC=$4
    DENSITY_THRESHOLD=$5
    DISTANCE_THRESHOLD=$6

$HADOOP_HOME/bin/hadoop jar $HADOOP_HOME/share/hadoop/tools/lib/hadoop-streaming-*.jar \
-input ${input_dir} \
-output ${output_dir} \
-partitioner org.apache.hadoop.mapred.lib.KeyFieldBasedPartitioner \
-jobconf mapred.reduce.tasks=600 \
-jobconf mapreduce.map.memory.mb=4096 \
-jobconf mapreduce.reduce.memory.mb=4096 \
-jobconf mapred.job.name=density_cluster \
-jobconf DENSITY_THRESHOLD=${DENSITY_THRESHOLD} \
-jobconf DISTANCE_THRESHOLD=${DISTANCE_THRESHOLD} \
-jobconf DC=${DC} \
-mapper "python script/cluster_mapper.py" \
-reducer "python script/cluster_reducer.py" \
-file script  \

}

start_date=$1
if [ -z ${start_date} ];then
    start_date=`date --date="-1 day" +%Y%m%d`
fi


year=`date -d $start_date +%Y`
month=`date -d $start_date +%m`
day=`date -d $start_date +%d`

input_first="/user/rd/dm/driver/drive_residence/gs_driver_first/$year/$month/$day/*"
for((i=1;i<=30;i++))
    do  
        day_input=`date --date="${start_date} -$i day" +%d`
        month_input=`date --date="${start_date} -$i day" +%m`
        year_input=`date --date="${start_date} -$i day" +%Y`
        hadoop fs -test -e /user/rd/dm/driver/drive_residence/gs_driver_first/$year_input/$month_input/$day_input/_SUCCESS
        [ $? -eq 0 ] && input_first="$input_first -input /user/rd/dm/driver/drive_residence/gs_driver_first/$year_input/$month_input/$day_input/*"
    done
output_first="/user/rd/dm/driver/drive_residence/gs_driver_first_cluster/$year/$month/$day"
$HADOOP_HOME/bin/hadoop fs -rm -r ${output_first}
cluster 1 "${input_first}" ${output_first} 0.3 5 0.8 

input_last="/user/rd/dm/driver/drive_residence/gs_driver_last/$year/$month/$day"
for((i=1;i<=30;i++))
    do  
        day_input=`date --date="${start_date} -$i day" +%d`
        month_input=`date --date="${start_date} -$i day" +%m`
        year_input=`date --date="${start_date} -$i day" +%Y`
        hadoop fs -test -e /user/rd/dm/driver/drive_residence/gs_driver_last/$year_input/$month_input/$day_input/_SUCCESS
        [ $? -eq 0 ] && input_last="$input_last -input /user/rd/dm/driver/drive_residence/gs_driver_last/$year_input/$month_input/$day_input"
    done
output_last="/user/rd/dm/driver/drive_residence/gs_driver_last_cluster/$year/$month/$day"
$HADOOP_HOME/bin/hadoop fs -rm -r ${output_last}
cluster 1 "${input_last}" ${output_last} 0.3 5 0.8 

input_accept="/user/rd/dm/driver/drive_residence/gs_driver_accept/$year/$month/$day"
for((i=1;i<=30;i++))
    do  
        day_input=`date --date="${start_date} -$i day" +%d`
        month_input=`date --date="${start_date} -$i day" +%m`
        year_input=`date --date="${start_date} -$i day" +%Y`
        hadoop fs -test -e /user/rd/dm/driver/drive_residence/gs_driver_accept/$year_input/$month_input/$day_input/_SUCCESS
        [ $? -eq 0 ] && input_accept="$input_accept -input /user/rd/dm/driver/drive_residence/gs_driver_accept/$year_input/$month_input/$day_input"
    done
output_accept="/user/rd/dm/driver/drive_residence/gs_driver_accept_cluster/$year/$month/$day"
$HADOOP_HOME/bin/hadoop fs -rm -r ${output_accept}
cluster 1 "${input_accept}" ${output_accept} 0.5 5 0.8 

input_rest="/user/rd/dm/driver/drive_residence/gs_driver_rest/$year/$month/$day"
for((i=1;i<=30;i++))
    do  
        day_input=`date --date="${start_date} -$i day" +%d`
        month_input=`date --date="${start_date} -$i day" +%m`
        year_input=`date --date="${start_date} -$i day" +%Y`
        hadoop fs -test -e /user/rd/dm/driver/drive_residence/gs_driver_rest/$year_input/$month_input/$day_input/_SUCCESS
        [ $? -eq 0 ] && input_rest="$input_rest -input /user/rd/dm/driver/drive_residence/gs_driver_rest/$year_input/$month_input/$day_input"
    done
output_rest="/user/rd/dm/driver/drive_residence/gs_driver_rest_cluster/$year/$month/$day"
$HADOOP_HOME/bin/hadoop fs -rm -r ${output_rest}
cluster 1 "${input_rest}" ${output_rest} 0.5 5 0.8 




