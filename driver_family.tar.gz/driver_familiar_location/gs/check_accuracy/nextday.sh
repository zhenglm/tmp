#!/bin/bash

date=$1
if [ -z ${date} ];then
    date=`date --date="-1 day" +%Y%m%d`
fi
year=`date -d $date +%Y`
month=`date -d $date +%m`
day=`date -d $date +%d`
OUTPUT_DIR="/user/rd/dm/driver/drive_residence/check_accuracy/last/$year/$month/$day"
$HADOOP_HOME/bin/hadoop fs -rm -r $OUTPUT_DIR
$HADOOP_HOME/bin/hadoop jar $HADOOP_HOME/share/hadoop/tools/lib/hadoop-streaming-*.jar \
-input /user/rd/dm/driver/drive_residence/gs_driver_last/2016/01/08  \
-input /user/rd/dm/auto_aftermarket/gs_driver_cluster_four_loc/$year/$month/$day \
-output  $OUTPUT_DIR \
-partitioner org.apache.hadoop.mapred.lib.KeyFieldBasedPartitioner \
-mapper "python script/map_last.py" \
-reducer "python script/red_first.py" \
-file   script \
-jobconf mapred.reduce.tasks=200 \
-jobconf mapred.job.name="check last location accuracy"

if [ $? -ne 0 ];then
    echo " check last location accuracy failed"
    exit 1
fi
<<note
OUTPUT_DIR="/user/rd/dm/driver/drive_residence/check_accuracy/first/$year/$month/$day"
$HADOOP_HOME/bin/hadoop fs -rm -r $OUTPUT_DIR
$HADOOP_HOME/bin/hadoop jar $HADOOP_HOME/share/hadoop/tools/lib/hadoop-streaming-*.jar \
-input /user/rd/dm/driver/drive_residence/gs_driver_first/$year/$month/$day  \
-input /user/rd/dm/auto_aftermarket/gs_driver_cluster_four_loc/$year/$month/$day \
-output  $OUTPUT_DIR \
-partitioner org.apache.hadoop.mapred.lib.KeyFieldBasedPartitioner \
-mapper "python script/map_first.py" \
-reducer "python script/red_first.py" \
-file   script \
-jobconf mapred.reduce.tasks=200 \
-jobconf mapred.job.name="check first location accuracy"

if [ $? -ne 0 ];then
    echo " check first location accuracy failed"
    exit 1
fi

OUTPUT_DIR="/user/rd/dm/driver/drive_residence/check_accuracy/firstlast/$year/$month/$day"
$HADOOP_HOME/bin/hadoop fs -rm -r $OUTPUT_DIR
$HADOOP_HOME/bin/hadoop jar $HADOOP_HOME/share/hadoop/tools/lib/hadoop-streaming-*.jar \
-input /user/rd/dm/auto_aftermarket/gs_driver_cluster_four_loc/$year/$month/$day \
-output  $OUTPUT_DIR \
-partitioner org.apache.hadoop.mapred.lib.KeyFieldBasedPartitioner \
-mapper "python script/map_firstlast.py" \
-reducer "python script/red_firstlast.py" \
-file   script \
-jobconf mapred.reduce.tasks=200 \
-jobconf mapred.job.name=check first location accuracy

if [ $? -ne 0 ];then
    echo " check last location accuracy failed"
    exit 1
fi
