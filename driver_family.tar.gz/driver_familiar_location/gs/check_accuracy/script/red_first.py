#!/usr/bin/env python
#-*- coding: utf-8 -*-

import sys
import math
MAX_DISTANCE = 0.5
PI = 3.1415926
EARTH_RADIUS=6378.137
def sphere_distance(lat1,lng1,lat2,lng2):
    radlat1=rad(lat1)
    radlat2=rad(lat2)
    a=radlat1-radlat2
    b=rad(lng1)-rad(lng2)
    s=2*math.asin(math.sqrt(math.pow(math.sin(a/2),2)+math.cos(radlat1)*math.cos(radlat2)*math.pow(math.sin(b/2),2)))

    s=round(float(s*EARTH_RADIUS),3)
    if s<0:
        return -s
    else:
        return s

def rad(d):
   return d * PI / 180.0;

def order_analy(data):
    min_dis = 100
    pid = data[0][0]
    if len(data) < 2 or data[0][1] == '1':
        return
    else:
        first_lng = float(data[0][2])
        first_lat = float(data[0][3])
        for i in range(1,len(data)):
            lng = float(data[i][2])
            lat = float(data[i][3])
            dis = sphere_distance(first_lat,first_lng,lat,lng)
            if dis < min_dis:
                min_dis = dis
        print pid + '\t' + str(min_dis)

data=[]
pre_key=''
for lines in sys.stdin:
    try:
        line=lines.strip('\n').split('\t')
        key=line[0]
        if(data!=[] and key!=pre_key):
            order_analy(data)
            data=[]
            data.append(line)
        elif(key and (pre_key=='' or key==pre_key)):
            data.append(line)
        pre_key=key
    except Exception as e :
      # sys.stderr.write("Error line:" + lines)
        pass
order_analy(data)
