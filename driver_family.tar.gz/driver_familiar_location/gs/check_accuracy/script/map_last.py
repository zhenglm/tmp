#!/usr/bin/env python
#-*- coding: utf-8 -*-

import sys
for lines in sys.stdin:
    line = lines.strip('\n').split('\t')
    if len(line) == 5:
        print line[0] + '\t' + '0' + '\t' + line[2] + '\t' + line[3] #pid 0 lng lat
    else :
        if line[3] == 'NULL' or line[3] == '\\N':   #last
            continue
        last_num = len(line[3].split(','))
        for i in range(last_num):
            gps_list = line[3].split(',')[i].split('-')
            print line[0] + '\t' + '1' + '\t'  + gps_list[0] + '\t' + gps_list[1] + '\t' + str(last_num)  #pid 1 lng lat num
