
for((i=1;i<30;i++))
do
    day=`date -d $i' days ago 20160111' +%Y%m%d`
    sh -x daily_driver_residence.sh $day   
done
