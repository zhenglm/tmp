package com.diditaxi.spark.ml.driver.dloc

import java.text.{DecimalFormat, SimpleDateFormat}
import org.apache.log4j.{Level, Logger}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.{DataFrame, Row}
import org.apache.spark.{SparkConf, SparkContext}
import scopt.OptionParser

import scala.collection.mutable
import scala.collection.mutable.{ArrayBuffer, Map, Set}

/**
 * Created by ChenjianpingJackie on 2015/12/26.
 */
object gs_driver_restloc {


  val PI=3.1415926
  val EARTH_RADIUS=6378.137
  val max_diff=0.03
  val df = new DecimalFormat()
  df.setMaximumFractionDigits(3)
  df.setMinimumFractionDigits(3)

  val sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val  MAX_DISTANCE=3000.0
  val  MIN_DIFF=0.3
  val  MIN_DC=0.1
  val MIN_TS=20
  val MAX_DIS=650

  case class Params(
                     input: String = null,
                     acceptinput:String = null,
                     outputrest: String = null,
                     outputaccept:String = null,
                     outputfirst: String = null,
                     outputlast: String = null
                     )

  def main(args: Array[String]) {
    val defaultParams = Params()

    val parser = new OptionParser[Params]("Driver") {
      head("Order Cluster")
      opt[String]("input")
        .required()
        .text("input data of driver gps ")
        .action((x, c) => c.copy(input = x))
      opt[String]("accept_input")
        .required()
        .text("input data of driver gps ")
        .action((x, c) => c.copy(acceptinput = x))
      opt[String]("output_rest")
        .text("output data of cluster")
        .action((x, c) => c.copy(outputrest = x))
      opt[String]("output_accept")
        .text("output data of input")
        .action((x, c) => c.copy(outputaccept = x))
      opt[String]("output_first")
        .text("output data of input")
        .action((x, c) => c.copy(outputfirst = x))
      opt[String]("output_last")
        .text("output data of input")
        .action((x, c) => c.copy(outputlast = x))
    }

    parser.parse(args, defaultParams).map { params =>
      run(params)
    } getOrElse {
      sys.exit(1)
    }
  }


  def LocFun(line:Row):dloc={
    var lng=df.format(line.getString(2).toDouble)
    var lat=df.format(line.getString(3).toDouble)
    new dloc(
      line.getString(0),
      line.getString(1),
      lng,
      lat,
      line.getString(4),
      1
    )
  }
  def LocFunFile(line:String):dloc={
    var parts=line.split("\\|")
    var lng=df.format(parts(18).toDouble)
    var lat=df.format(parts(19).toDouble)
    new dloc(
      parts(1),
      parts(0),
      lng,
      lat,
      parts(23),
      1
    )
  }
  def LocFunArray(line:Array[String]):dloc={
    var parts=line
    var lng=df.format(parts(18).toDouble)
    var lat=df.format(parts(19).toDouble)
    new dloc(
      parts(1),
      parts(0),
      lng,
      lat,
      parts(23),
      1
    )
  }

  def acceptFile(line:Row):dloc={
    var lng=df.format(line.getString(2).toDouble)
    var lat=df.format(line.getString(3).toDouble)
    new dloc(
      line.getString(0),
      line.getString(1),
      lng,
      lat,
      "1",
      1
    )
  }


  def rad(d:Double):Double={
    return d*PI/180.0
  }

  def sphere_distance(lng1:Double,lat1:Double,lng2:Double,lat2:Double): Double ={
    var radlat1=rad(lat1)
    var radlat2=rad(lat2)
    var a=radlat1-radlat2
    var b=rad(lng1)-rad(lng2)
    var s=2*math.asin(math.sqrt(math.pow(math.sin(a/2),2)+math.cos(radlat1)*math.cos(radlat2)*math.pow(math.sin(b/2),2)))
    s=Math.round(s*EARTH_RADIUS*1000)
    return Math.max(s,-s)
  }


  /**
    * 计算两个时间戳之间的时间差，以分钟为单位
    * @param time1
    * @param time2
    * @return
    */
  def getminitespace(time1:String,time2:String): Double ={
    var sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val d1 = sdf.parse(time1).getTime()
    val d2 = sdf.parse(time2).getTime()
    val m = Math.abs(d2-d1) / (60*1000)
    return  m
  }

  def isValidDate(str:String) : Boolean={
    var convertSuccess=true
    // 指定日期格式为四位年/两位月份/两位日期，注意yyyy/MM/dd区分大小写；
    var  format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    try {
      // 设置lenient为false. 否则SimpleDateFormat会比较宽松地验证日期，比如2007/02/29会被接受，并转换成2007/03/01
      format.setLenient(false)
      format.parse(str);
    } catch {case _: Exception=>
      convertSuccess=false
    }
    return convertSuccess
  }


  /**
    * 获得一个司机停靠超过20分钟的位置信息，每次停靠的位置信息存一次
    * @param data
    * @return
    */
  //calculate driver rest location  20分钟内轨迹距离一直在500米范围内。
  def getrest(data:Iterable[dloc]):Array[dloc]={
    val dd=data.toArray[dloc]
    val d=dd.sortBy(x=>x.loc_time)
    var result=ArrayBuffer[dloc]()
    var i=0
    var j=1
    var flag=0

    while(i<d.length && j<d.length){
      try {
        var a=d(i)
        var b=d(j)
        var min_distance=MIN_DC
        //if (isValidDate(a.loc_time) && isValidDate(b.loc_time)){
        var timespace=getminitespace(a.loc_time,b.loc_time)
        if (timespace<MIN_TS){j+=1}
        else {
          //步长
          var delta=math.max(math.round((j-i)*1.0/10),1)  //两点时间差到20分钟时，对中间的点抽样判断是否都在500米范围内
          var num=(j-i)/delta  //space number
          var k=1
          var IsRest= true
          while(k<=num && IsRest){
            var z=0
            if (k==num){ z =j}
            else {z=(i+k*delta).toInt}
            var lng1=d(i).lng.toDouble
            var lat1=d(i).lat.toDouble
            var lng2=d(z).lng.toDouble
            var lat2=d(z).lat.toDouble
            var distance=sphere_distance(lng1,lat1,lng2,lat2)
            if (distance<=MAX_DIS){k+=1}
            else{i=z;flag=0;IsRest=false}
          } // end of while
          if (k==(num+1)) {
            val one_dloc = new dloc(d(i).driver_id,d(i).loc_time, d(i).lng, d(i).lat, d(i).state,d(i).count)
            if (flag==0) {result += one_dloc;flag =1}
            i = j
            j += 1
          }
          else if(IsRest) {i=j;j+=1}
        }}
      catch{case x:Exception=>{ i+=1;j+=1}}
    }
    result.toArray
  }
 //calculate first and last location 收发车地
  def getfirstlast(data:Iterable[dloc]):Map[dloc,dloc]= {
    val dd = data.toArray[dloc]
    val d = dd.sortBy(x => x.loc_time)
    var first = ArrayBuffer[dloc]()
    //var d = ArrayBuffer[dloc]()
    var i = 0
    var flag = 0
    var timespace = 0.0
    var first_dloc = d(0)    //
    if (d.length>10) {first_dloc = d(9)}
    var last_dloc = d(d.length - 1)  //d数组的最后一个六元组

    var firstlast = mutable.HashMap[dloc,dloc]()
    for (i <- 0 to dd.length - 2) {
      timespace = getminitespace(d(i).loc_time, d(i+1).loc_time)
      if (timespace >= 360)
      {last_dloc = d(i)
        first_dloc = d(i+1)
        if (d.length >(i+10)) {first_dloc = d(i+10)}
      }
    } // end of for
    firstlast +=(first_dloc -> last_dloc)
  }


  def run(params: Params) {
    val conf = new SparkConf().setAppName(s"driver familiar location")
    val sc = new SparkContext(conf)
    Logger.getRootLogger.setLevel(Level.WARN)

    assert(params.input!=null)
    val hiveContext=new HiveContext(sc)
    import hiveContext._
    val acceptorder:DataFrame=sql(params.acceptinput).repartition(sc.defaultParallelism)
    val inputdata=sc.textFile(params.input).repartition(sc.defaultParallelism)
    var acceptdata=acceptorder.map(line=>acceptFile(line)).map(line=>s"${line.driver_id}\t${line.loc_time}\t${line.lng}\t${line.lat}\t${line.count}").saveAsTextFile(params.outputaccept)
    //var locdata=inputdata.map(line=>LocFunFile(line)).groupBy(x=>(x.driver_id)).repartition(sc.defaultParallelism).cache()
    //var locdata=inputdata.map(s=>s.split("\\|")).filter(s=>s.length>23).map(line=>LocFunArray(line)).groupBy(x=>(x.driver_id)).repartition(sc.defaultParallelism).cache()
    //var locdata=inputdata.map(s=>s.split("\\|")).filter(s=>(s.length>23 && s(18)(0)>='0' && s(18)(0)<='9' && s(19)(0)>='0' && s(19)(0)<='9' )).map(line=>LocFunArray(line)).groupBy(x=>(x.driver_id)).cache()
    var locdata=inputdata.map(s=>s.split("\\|"))
        .filter(s=>(s.length>23 && s(18)(0)>='0' && s(18)(0)<='9' && s(19)(0)>='0' && s(19)(0)<='9' ))
        .map(line=>LocFunArray(line)).groupBy(x=>(x.driver_id)).repartition(sc.defaultParallelism).cache()
    //println("轨迹数据大小为"+locdata.count)

    var firstlast = locdata.map(a=>(a._1,getfirstlast(a._2))).flatMap(a=>a._2).cache()
    firstlast.map(line=>s"${line._1.driver_id}\t${line._1.loc_time}\t${line._1.lng}\t${line._1.lat}\t${line._1.count}").repartition(2).saveAsTextFile(params.outputfirst)
    firstlast.map(line=>s"${line._2.driver_id}\t${line._2.loc_time}\t${line._2.lng}\t${line._2.lat}\t${line._2.count}").repartition(2).saveAsTextFile(params.outputlast)

    var rest = locdata.map(a=>(a._1,getrest(a._2))).flatMap(a=>a._2)
    rest.map(line=>s"${line.driver_id}\t${line.loc_time}\t${line.lng}\t${line.lat}\t${line.count}").repartition(2).saveAsTextFile(params.outputrest)

    sc.stop()
  }
}

