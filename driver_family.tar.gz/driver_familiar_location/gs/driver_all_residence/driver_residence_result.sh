#!/bin/bash
date=$1
if [ -z ${date} ]
then
    date=`date -d yesterday +%Y%m%d`
fi

day=`date -d ${date} +%d`
month=`date -d ${date} +%m`
year=`date -d ${date} +%Y`
cur_dir=`pwd`
cd ../cluster/gs && sh -x cluster_run.sh $date > cluster.${date}.log 2>&1 
cd $cur_dir
cd ../hive
sh -x first_login_transform.hive $date
sh -x last_login_transform.hive $date
sh -x accept_login_transform.hive $date
sh -x rest_login_transform.hive $date
sh -x final_table_gs_drive_loc.hive $date 
