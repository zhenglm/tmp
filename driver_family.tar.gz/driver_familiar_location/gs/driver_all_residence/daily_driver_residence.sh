#!/bin/bash
DATE=$1
if [ -z ${DATE} ]
then
    DATE=`date -d yesterday +%Y%m%d`
fi

DAY=`date -d ${DATE} +%d`
MONTH=`date -d ${DATE} +%m`
YEAR=`date -d ${DATE} +%Y`

END_DATE=`date -d ${DATE} +%Y%m%d`
START_DATE=`date -d "${DATE} 10 days ago" +%Y%m%d`

TABLE_NAME='gs_driver_residence_cs'
OUTPUT_DIR='/user/rd/dm/driver/drive_residence/gs_driver_rest'
OUTPUT_ACCEPT='/user/rd/dm/driver/drive_residence/gs_driver_accept'
OUTPUT_FIRST='/user/rd/dm/driver/drive_residence/gs_driver_first'
OUTPUT_LAST='/user/rd/dm/driver/drive_residence/gs_driver_last'
HIVE_PATH="${OUTPUT_DIR}"
#INPUT_SQL="select dphone,createtime,txlng,txlat,state from ods.ods_gsdriverloc where state!='10000' and concat(year,month,day)= ${END_DATE}"
INPUT_SQL="select param['driver_id'],param['timestamp'],param['driver_lng'],param['driver_lat'] from gulfstream_ods.g_new_strive_log where concat(year,month,day)= ${DATE}"
INPUT_FILE="/user/xiaoju/data/bi/etllog/gsdriverloc/${YEAR}/${MONTH}/${DAY}/*"

hadoop fs -test -d ${OUTPUT_DIR}/${YEAR}/${MONTH}/${DAY}
[ $? -eq 0 ] && hadoop fs -rm -r ${OUTPUT_DIR}/${YEAR}/${MONTH}/${DAY}
hadoop fs -test -d ${OUTPUT_FIRST}/${YEAR}/${MONTH}/${DAY}
[ $? -eq 0 ] && hadoop fs -rm -r ${OUTPUT_FIRST}/${YEAR}/${MONTH}/${DAY}
hadoop fs -test -d ${OUTPUT_LAST}/${YEAR}/${MONTH}/${DAY}
[ $? -eq 0 ] && hadoop fs -rm -r ${OUTPUT_LAST}/${YEAR}/${MONTH}/${DAY}
hadoop fs -test -d ${OUTPUT_ACCEPT}/${YEAR}/${MONTH}/${DAY}
[ $? -eq 0 ] && hadoop fs -rm -r ${OUTPUT_ACCEPT}/${YEAR}/${MONTH}/${DAY}

$SPARK_HOME/bin/spark-submit \
                --total-executor-cores 1200 \
                --executor-memory 50g \
                --driver-memory 4g \
                --conf spark.storage.memoryFraction=0.5 \
                --conf spark.default.parallelism=2400 \
                --class com.diditaxi.spark.ml.driver.dloc.gs_driver_restloc \
                --queue default \
                didi_ml.jar \
                --input "${INPUT_FILE}" \
                --accept_input "${INPUT_SQL}" \
                --output_rest "${OUTPUT_DIR}/${YEAR}/${MONTH}/${DAY}" \
                --output_accept "${OUTPUT_ACCEPT}/${YEAR}/${MONTH}/${DAY}" \
                --output_first "${OUTPUT_FIRST}/${YEAR}/${MONTH}/${DAY}" \
                --output_last "${OUTPUT_LAST}/${YEAR}/${MONTH}/${DAY}" \


